gcc -shared -fPIC -DPIC voice2aftertouch.c -o voice2aftertouch.so
